// Basic interactive behavior for Disaster AI Hub demo
console.log("Disaster AI Hub script loaded");

// Simple DOM refs
const chatArea = document.getElementById('chat-area');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');

const disasterList = document.getElementById('disaster-list');
const weatherDiv = document.getElementById('weather');

const gameArea = document.getElementById('game-area');
const nextBtn = document.getElementById('next-btn');
const scoreCard = document.getElementById('scorecard');
const progressEl = document.getElementById('progress');
const certArea = document.getElementById('certificate-area');
const downloadBtn = document.getElementById('download-cert-btn');

// ---------- Minimal AI chat (placeholder) ----------
sendBtn.addEventListener('click', async () => {
  const txt = userInput.value.trim();
  if(!txt) return;
  appendChat('user', txt);
  userInput.value = '';
  await sleep(250);
  await botReply(txt);
});

function appendChat(kind, text){
  const p = document.createElement('p');
  p.className = kind === 'user' ? 'user' : 'ai';
  p.innerHTML = `<strong>${kind === 'user' ? 'You' : 'AI'}:</strong> ${escapeHtml(text)}`;
  chatArea.appendChild(p);
  chatArea.scrollTop = chatArea.scrollHeight;
}

function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }

async function botReply(userText){
  // typing placeholder
  const typing = document.createElement('p');
  typing.className = 'ai';
  typing.innerHTML = '<em>AI is typing...</em>';
  chatArea.appendChild(typing);
  chatArea.scrollTop = chatArea.scrollHeight;
  await sleep(900);
  typing.remove();

  // simple heuristics for demo
  let reply = "Nice question — here's a tip: stay aware, follow local authority instructions.";
  if(/earthquake/i.test(userText)) reply = "If an earthquake occurs: Drop, Cover, and Hold On. Stay away from windows.";
  if(/flood/i.test(userText)) reply = "In floods: move to high ground, avoid driving through water, unplug appliances.";
  appendChat('ai', reply);
}

// ---------- Weather (demo static city) ----------
async function loadWeather(){
  try{
    // Demo: show static info to avoid API key issues
    weatherDiv.innerHTML = 'Weather: Mumbai — Clear, 29°C';
  }catch(e){
    weatherDiv.innerHTML = 'Weather: unavailable';
  }
}
loadWeather();

// ---------- Disaster alerts (demo set) ----------
const demoAlerts = [
  {level:'danger', text:'Flood warning for riverside sectors — prepare to move to higher ground.'},
  {level:'warning', text:'Severe thunderstorm watch in the northern district.'},
  {level:'info', text:'Heat advisory today between 11:00 - 16:00.'}
];

function showAlerts(){
  disasterList.innerHTML = '';
  demoAlerts.forEach((a, i) => {
    const d = document.createElement('div');
    d.className = 'alert';
    d.innerHTML = `<div><strong>${a.level.toUpperCase()}</strong></div><div style="margin-left:8px;">${a.text}</div>`;
    disasterList.appendChild(d);
    // optional native desktop notification (user permission)
    setTimeout(()=> tryNotify(a.text), 800 + i*600);
  });
}
function tryNotify(msg){
  if("Notification" in window && Notification.permission === "granted"){
    new Notification("Disaster Alert", {body: msg});
  } else if("Notification" in window && Notification.permission !== "denied"){
    Notification.requestPermission().then(p => { if(p === 'granted') new Notification("Disaster Alert", {body: msg});});
  }
}
showAlerts();

// ---------- Story game ----------
const questions = [
  {q:"If you feel the ground shake suddenly, what should you do first?", choices:['Run outside','Drop, Cover, Hold On','Call friend'], answer:1},
  {q:"During a flood, where is the safest place?", choices:['Lower floor','High ground','Basement'], answer:1},
  {q:"What item is best to keep in an emergency kit?", choices:['Batteries & torch','Candles only','Blankets only'], answer:0}
];
let score = 0, current = 0;

function renderQuestion(){
  progressEl.textContent = (current+1) + ' / ' + questions.length;
  const q = questions[current];
  gameArea.innerHTML = '<div class="qtext">'+ q.q +'</div>';
  const ul = document.createElement('div'); ul.style.marginTop='12px';
  q.choices.forEach((c, idx) => {
    const b = document.createElement('button');
    b.className='btn'; b.style.margin='6px';
    b.textContent = c;
    b.addEventListener('click', ()=> chooseAnswer(idx));
    ul.appendChild(b);
  });
  gameArea.appendChild(ul);
  scoreCard.textContent = 'Score: ' + score;
}
function chooseAnswer(idx){
  const isCorrect = idx === questions[current].answer;
  if(isCorrect){ score += 10; animateScore(score); }
  current++;
  if(current >= questions.length){
    gameArea.innerHTML = '<strong>Mission Complete!</strong>';
    generateCertificate(promptName(), score);
    confetti({particleCount:120, spread:90, origin:{y:0.6}});
  } else {
    renderQuestion();
  }
}
function animateScore(final){
  let cur = parseInt(scoreCard.textContent.replace('Score: ',''));
  const t = setInterval(()=> {
    if(cur < final){ cur++; scoreCard.textContent='Score: '+cur; } else clearInterval(t);
  }, 20);
}

function promptName(){
  const n = prompt("Enter your name for the certificate:", "Player");
  return n && n.trim() !== '' ? n.trim() : 'Player';
}

renderQuestion();

// ---------- Certificate generation ----------
function generateCertificate(name, score){
  certArea.innerHTML = `
    <div id="certificate">
      <h3>🎖️ Mission Completed</h3>
      <p>Presented to <strong>${escapeHtml(name)}</strong></p>
      <p>Score: <strong>${score}</strong></p>
      <small>Date: ${new Date().toLocaleDateString()}</small>
    </div>
  `;
  downloadBtn.style.display = 'inline-block';
}

// download certificate as PDF
downloadBtn.addEventListener('click', ()=> {
  const { jsPDF } = window.jspdf;
  const el = document.getElementById('certificate');
  if(!el) return alert('No certificate to download');
  html2canvas(el).then(canvas=>{
    const img = canvas.toDataURL('image/png');
    const pdf = new jsPDF({orientation:'portrait'});
    const w = pdf.internal.pageSize.getWidth();
    const h = (canvas.height * w) / canvas.width;
    pdf.addImage(img, 'PNG', 0, 10, w, h);
    pdf.save('Mission_Certificate.pdf');
  });
});

// ---------- helpers ----------
function escapeHtml(s){ return (s+'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
